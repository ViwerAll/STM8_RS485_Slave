#define STM8S103
#define USE_STDPERIPH_DRIVER
#include "stm8s.h"
#define assert_param(expr) ((void)0)