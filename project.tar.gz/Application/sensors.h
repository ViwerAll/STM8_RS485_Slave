#ifndef __SENSORS_H
#define __SENSORS_H

#include <stdint.h>

void Sensors_Init(void);
void Sensors_ReadAll(void);
uint8_t Sensors_GetKeys(void);
uint8_t Sensors_GetMotion(void);
uint16_t Sensors_GetTemperature(void);
uint16_t Sensors_GetHumidity(void);
uint16_t Sensors_GetLight(void);

#endif