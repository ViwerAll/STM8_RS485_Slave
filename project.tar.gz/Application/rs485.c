#include "stm8s.h"
#include "rs485.h"
#include "config.h"

#define DE_RE_PORT GPIOD
#define DE_RE_PIN  GPIO_PIN_4

static volatile uint8_t tx_buf[TX_BUF_SIZE];
static volatile uint8_t tx_len = 0;
static volatile uint8_t tx_pos = 0;

void RS485_Init(void) {
    // UART1 на 115200 8N1
    UART1_DeInit();
    UART1_Init((uint32_t)BAUDRATE,
               UART1_WORDLENGTH_8D,
               UART1_STOPBITS_1,
               UART1_PARITY_NO,
               UART1_SYNCMODE_CLOCK_DISABLE,
               UART1_MODE_TXRX_ENABLE);
    
    // Пин управления направлением
    GPIO_Init(DE_RE_PORT, DE_RE_PIN, GPIO_MODE_OUT_PP_HIGH_FAST);
    RS485_SetRxMode();
    
    // Разрешение прерываний
    UART1_ITConfig(UART1_IT_RXNE, ENABLE);
    enableInterrupts();
}

void RS485_SetTxMode(void) {
    GPIO_WriteHigh(DE_RE_PORT, DE_RE_PIN);
    // Задержка установления уровня
    for(volatile uint16_t i = 0; i < TX_ENABLE_DELAY; i++);
}

void RS485_SetRxMode(void) {
    GPIO_WriteLow(DE_RE_PORT, DE_RE_PIN);
}

void RS485_Send(uint8_t *data, uint8_t len) {
    if(len == 0 || len > TX_BUF_SIZE) return;
    
    // Копируем в буфер (volatile требует явного копирования)
    uint8_t i;
    for(i = 0; i < len; i++) {
        tx_buf[i] = data[i];  // Копируем из не-volatile в volatile
    }
    tx_len = len;
    tx_pos = 0;
    
    // Начинаем передачу
    RS485_SetTxMode();
    UART1_ITConfig(UART1_IT_TXE, ENABLE);
    UART1_SendData8(tx_buf[0]);
    tx_pos = 1;
}

uint8_t RS485_ReceiveByte(void) {
    return UART1_ReceiveData8();
}

uint8_t RS485_DataAvailable(void) {
    return UART1_GetFlagStatus(UART1_FLAG_RXNE);
}

void RS485_FlushRx(void) {
    while(UART1_GetFlagStatus(UART1_FLAG_RXNE)) {
        UART1_ReceiveData8();
    }
}

// Прерывание передачи
#pragma vector = 17 
__interrupt void UART1_TX_IRQHandler(void) {
    if(tx_pos < tx_len) {
        UART1_SendData8(tx_buf[tx_pos]);
        tx_pos++;
    } else {
        UART1_ITConfig(UART1_IT_TXE, DISABLE);
        RS485_SetRxMode();
    }
}

// Прерывание приема
#pragma vector = 18 
__interrupt void UART1_RX_IRQHandler(void) {
    // Прием обрабатывается в основном цикле
    UART1_ClearITPendingBit(UART1_IT_RXNE);
}