#include "stm8s.h"
#include "config.h"
#include "registers.h"
#include "rs485.h"
#include "sensors.h"
#include "protocol.h"

// Глобальные переменные
static uint8_t rx_buffer[RX_BUF_SIZE];
static uint8_t rx_index = 0;
static uint8_t tx_buffer[TX_BUF_SIZE];
static uint16_t event_timer = 0;
static uint8_t pending_events = 0;
static uint8_t last_keys = 0;
static uint8_t last_motion = 0;

// Инициализация таймера для событий
void TIM4_Init(void) {
    TIM4_DeInit();
    // 16 МГц / 128 = 125 кГц, период 125 = 1 мс
    TIM4_TimeBaseInit(TIM4_PRESCALER_128, 125);
    TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);
    TIM4_Cmd(ENABLE);
}

// Инициализация I2C для BH1750
void I2C_Configuration(void) {
    I2C_DeInit();
    // Параметры: 100 кГц, 7-битный адрес, свой адрес 0x00 (не используется), такт 16 МГц
    I2C_Init(100000, 0x00, I2C_DUTYCYCLE_2, I2C_ACK_CURR, I2C_ADDMODE_7BIT, 16);
    I2C_Cmd(ENABLE);
}

void System_Init(void) {
    // Отключить watchdog (правильный вызов для IAR)
    IWDG_Enable(); // Без параметров в этой версии библиотеки
    
    // Настройка тактирования 16 МГц
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
    
    // Инициализация модулей
    Reg_Init();
    Sensors_Init();
    RS485_Init();
    I2C_Configuration(); // Используй свою функцию, а не библиотечную
    TIM4_Init();
    
    enableInterrupts();
}

// Проверка событий
void CheckEvents(void) {
    uint8_t current_keys = Sensors_GetKeys();
    uint8_t current_motion = Sensors_GetMotion();
    uint16_t event_mask = Reg_GetEventMask();
    
    if(Reg_EventsEnabled()) {
        // Клавиши
        if((event_mask & 0x0001) && (current_keys != last_keys)) {
            pending_events |= 0x01;
            last_keys = current_keys;
            event_timer = Reg_Read(REG_EVENT_TIMEOUT);
        }
        
        // Движение
        if((event_mask & 0x0002) && (current_motion != last_motion)) {
            pending_events |= 0x02;
            last_motion = current_motion;
            event_timer = Reg_Read(REG_EVENT_TIMEOUT);
        }
    }
}

// Отправка событий с CSMA/CD
void SendEvents(void) {
    if(pending_events == 0 || event_timer > 0) return;
    
    static uint8_t retry_count = 0;
    static uint16_t backoff_time = 0;
    
    if(backoff_time > 0) {
        backoff_time--;
        return;
    }
    
    // Проверка линии (упрощенная)
    if(RS485_DataAvailable()) {
        // Коллизия - откат
        retry_count++;
        if(retry_count > 16) {
            pending_events = 0;
            retry_count = 0;
            return;
        }
        
        // Экспоненциальный откат
        uint16_t slots = 1 << (retry_count < 10 ? retry_count : 10);
        backoff_time = slots * EVENT_SLOT_TIME;
        return;
    }
    
    // Отправка события
    uint8_t frame_len = 0;
    if(pending_events & 0x01) {
        frame_len = Protocol_BuildEventFrame(tx_buffer, 0x01, last_keys);
        pending_events &= ~0x01;
    } else if(pending_events & 0x02) {
        frame_len = Protocol_BuildEventFrame(tx_buffer, 0x02, last_motion);
        pending_events &= ~0x02;
    }
    
    if(frame_len > 0) {
        RS485_Send(tx_buffer, frame_len);
        retry_count = 0;
    }
}

int main(void) {
    System_Init();
    
    while(1) {
        // Прием данных
        if(RS485_DataAvailable()) {
            if(rx_index < RX_BUF_SIZE) {
                rx_buffer[rx_index++] = RS485_ReceiveByte();
            }
            
            // Проверка завершения фрейма (3.5 символа тишины - упрощенно)
            static uint16_t silence_timer = 0;
            silence_timer = 100; // ~1 мс
            
            if(silence_timer == 0 && rx_index > 0) {
                // Обработка фрейма
                uint8_t tx_len = Protocol_ProcessFrame(rx_buffer, rx_index, tx_buffer);
                if(tx_len > 0) {
                    RS485_Send(tx_buffer, tx_len);
                }
                rx_index = 0;
                RS485_FlushRx();
            }
        }
        
        // Проверка событий
        CheckEvents();
        
        // Отправка событий
        SendEvents();
        
        // Спим до прерывания
        __halt();
    }
}

// Обработчик прерывания таймера
#pragma vector = 23 // Вместо TIM4_OVR_UIF_vector
__interrupt void TIM4_UPD_OVF_IRQHandler(void) {
    TIM4_ClearFlag(TIM4_FLAG_UPDATE);
    
    if(event_timer > 0) event_timer--;
    
    // Здесь также уменьшаются другие таймеры
}