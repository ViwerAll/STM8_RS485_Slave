#ifndef __RS485_H
#define __RS485_H

#include <stdint.h>

void RS485_Init(void);
void RS485_Send(uint8_t *data, uint8_t len);
void RS485_SetTxMode(void);
void RS485_SetRxMode(void);
uint8_t RS485_ReceiveByte(void);
uint8_t RS485_DataAvailable(void);
void RS485_FlushRx(void);

#endif