#ifndef __CONFIG_H
#define __CONFIG_H

#include "stm8s.h"

// Адресация
#define DEFAULT_ADDRESS     1
#define BROADCAST_ADDRESS   0xFF
#define MAX_ADDRESS         247

// RS-485 параметры
#define BAUDRATE            115200
#define TX_ENABLE_DELAY     2     // мкс

// Таймауты
#define MASTER_POLL_TIMEOUT 10000 // мс
#define EVENT_DEBOUNCE      50    // мс
#define EVENT_TIMEOUT       100   // мс
#define EVENT_SLOT_TIME     2     // мс
#define false               0
#define true                1

// Карта регистров
typedef enum {
    REG_FW_VERSION     = 0x0000,
    REG_KEY_STATE      = 0x0001,
    REG_TEMPERATURE    = 0x0002,
    REG_HUMIDITY       = 0x0003,
    REG_LIGHT          = 0x0004,
    REG_MOTION         = 0x0005,
    REG_CONFIG         = 0x0010,
    REG_EVENT_TIMEOUT  = 0x0011,
    REG_EVENT_MASK     = 0x0012,
    REG_SLAVE_ADDR     = 0x0013,
    REG_COUNT          = 32
} RegisterMap_t;

// Флаги конфигурации
#define CFG_EVENTS_EN   0x0001
#define CFG_MOTION_LATCH 0x0002

// Флаги ошибок датчиков
#define SENSOR_ERROR    0x8000

// Команды протокола
#define CMD_READ_REG    0x03
#define CMD_WRITE_REG   0x06
#define CMD_EVENT       0x41

// Размеры буферов
#define RX_BUF_SIZE     64
#define TX_BUF_SIZE     64

#endif