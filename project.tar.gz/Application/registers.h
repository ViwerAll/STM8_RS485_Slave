#ifndef __REGISTERS_H
#define __REGISTERS_H

#include <stdint.h>

void Reg_Init(void);
uint16_t Reg_Read(uint16_t addr);
uint8_t Reg_Write(uint16_t addr, uint16_t value);
void Reg_UpdateSensor(uint16_t addr, uint16_t value);
uint16_t Reg_GetEventMask(void);
uint8_t Reg_GetAddress(void);
uint8_t Reg_EventsEnabled(void);

#endif