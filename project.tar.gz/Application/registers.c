#include "registers.h"
#include "config.h"

static volatile uint16_t regs[REG_COUNT];

void Reg_Init(void) {
    regs[REG_FW_VERSION] = 0x0100;
    regs[REG_KEY_STATE] = 0x0000;
    regs[REG_TEMPERATURE] = SENSOR_ERROR;
    regs[REG_HUMIDITY] = SENSOR_ERROR;
    regs[REG_LIGHT] = SENSOR_ERROR;
    regs[REG_MOTION] = 0x0000;
    regs[REG_CONFIG] = CFG_EVENTS_EN;
    regs[REG_EVENT_TIMEOUT] = EVENT_TIMEOUT;
    regs[REG_EVENT_MASK] = 0x0003; // Клавиши + движение
    regs[REG_SLAVE_ADDR] = DEFAULT_ADDRESS;
}

uint16_t Reg_Read(uint16_t addr) {
    return (addr < REG_COUNT) ? regs[addr] : 0xFFFF;
}

uint8_t Reg_Write(uint16_t addr, uint16_t value) {
    if(addr >= REG_COUNT) return 0;
    
    switch(addr) {
        case REG_FW_VERSION:
        case REG_KEY_STATE:
        case REG_TEMPERATURE:
        case REG_HUMIDITY:
        case REG_LIGHT:
        case REG_MOTION:
            return 0;
        case REG_SLAVE_ADDR:
            if(value < 1 || value > MAX_ADDRESS) return 0;
            regs[addr] = value;
            return 1;
        default:
            regs[addr] = value;
            return 1;
    }
}

void Reg_UpdateSensor(uint16_t addr, uint16_t value) {
    if(addr < REG_COUNT) {
        regs[addr] = value;
    }
}

uint16_t Reg_GetEventMask(void) {
    return regs[REG_EVENT_MASK];
}

uint8_t Reg_GetAddress(void) {
    return (uint8_t)regs[REG_SLAVE_ADDR];
}

uint8_t Reg_EventsEnabled(void) {
    return (regs[REG_CONFIG] & CFG_EVENTS_EN) ? 1 : 0;
}