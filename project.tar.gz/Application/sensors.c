#include "stm8s.h"
#include "sensors.h"
#include "config.h"

// Пины
#define KEY_PORT    GPIOC
#define KEY_PINS    (GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6)
#define MOTION_PORT GPIOD
#define MOTION_PIN  GPIO_PIN_2
#define DHT11_PORT  GPIOD
#define DHT11_PIN   GPIO_PIN_1

static uint8_t keys_state = 0;
static uint8_t motion_state = 0;

void Sensors_Init(void) {
    // Кнопки
    GPIO_Init(KEY_PORT, KEY_PINS, GPIO_MODE_IN_PU_NO_IT);
    
    // Датчик движения (реле)
    GPIO_Init(MOTION_PORT, MOTION_PIN, GPIO_MODE_IN_PU_NO_IT);
    
    // DHT11
    GPIO_Init(DHT11_PORT, DHT11_PIN, GPIO_MODE_OUT_OD_HIZ_FAST);
    GPIO_WriteHigh(DHT11_PORT, DHT11_PIN);
    
    // I2C для BH1750 уже настроен в main
}

uint8_t Sensors_GetKeys(void) {
    uint8_t port = GPIO_ReadInputData(KEY_PORT);
    uint8_t keys = (~port >> 3) & 0x0F; // PC3-PC6 -> биты 0-3
    return keys;
}

uint8_t Sensors_GetMotion(void) {
    // 1 = движение, 0 = нет движения
    return (GPIO_ReadInputPin(MOTION_PORT, MOTION_PIN) == RESET) ? 1 : 0;
}

// Заглушки для датчиков - реализуй по мере необходимости
uint16_t Sensors_GetTemperature(void) { return SENSOR_ERROR; }
uint16_t Sensors_GetHumidity(void) { return SENSOR_ERROR; }
uint16_t Sensors_GetLight(void) { return SENSOR_ERROR; }

void Sensors_ReadAll(void) {
    keys_state = Sensors_GetKeys();
    motion_state = Sensors_GetMotion();
    // Здесь чтение DHT11 и BH1750
}