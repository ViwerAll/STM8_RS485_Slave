#ifndef __PROTOCOL_H
#define __PROTOCOL_H

#include <stdint.h>

uint8_t Protocol_ProcessFrame(uint8_t *rx_buf, uint8_t rx_len, uint8_t *tx_buf);
uint8_t Protocol_BuildEventFrame(uint8_t *tx_buf, uint8_t event_type, uint16_t data);
uint16_t Protocol_CRC16(uint8_t *data, uint8_t length);

#endif