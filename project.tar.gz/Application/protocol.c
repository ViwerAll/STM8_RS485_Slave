#include "protocol.h"
#include "registers.h"
#include "config.h"

typedef struct {
    uint8_t address;
    uint8_t function;
    uint16_t start_reg;
    uint16_t reg_count;
    uint8_t data[0];
} ModbusFrame_t;

uint16_t Protocol_CRC16(uint8_t *data, uint8_t length) {
    uint16_t crc = 0xFFFF;
    for(uint8_t i = 0; i < length; i++) {
        crc ^= (uint16_t)data[i];
        for(uint8_t j = 0; j < 8; j++) {
            if(crc & 0x0001) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
}

uint8_t Protocol_ProcessFrame(uint8_t *rx_buf, uint8_t rx_len, uint8_t *tx_buf) {
    if(rx_len < 6) return 0;
    
    ModbusFrame_t *frame = (ModbusFrame_t *)rx_buf;
    
    // Проверка CRC
    uint16_t crc_calc = Protocol_CRC16(rx_buf, rx_len - 2);
    uint16_t crc_recv = (rx_buf[rx_len-1] << 8) | rx_buf[rx_len-2];
    if(crc_calc != crc_recv) return 0;
    
    // Проверка адреса
    if(frame->address != Reg_GetAddress() && 
       frame->address != BROADCAST_ADDRESS) return 0;
    
    uint8_t tx_len = 0;
    tx_buf[0] = frame->address;
    tx_buf[1] = frame->function;
    
    switch(frame->function) {
        case CMD_READ_REG: {
            uint16_t start = frame->start_reg;
            uint16_t count = frame->reg_count;
            
            if(start + count > REG_COUNT) {
                tx_buf[1] |= 0x80; // Код ошибки
                tx_buf[2] = 0x02; // Недопустимый адрес
                tx_len = 3;
            } else {
                tx_buf[2] = count * 2;
                for(uint8_t i = 0; i < count; i++) {
                    uint16_t val = Reg_Read(start + i);
                    tx_buf[3 + i*2] = val >> 8;
                    tx_buf[4 + i*2] = val & 0xFF;
                }
                tx_len = 3 + count * 2;
            }
            break;
        }
            
        case CMD_WRITE_REG: {
            if(frame->start_reg + 1 > REG_COUNT) {
                tx_buf[1] |= 0x80;
                tx_buf[2] = 0x02;
                tx_len = 3;
            } else {
                uint16_t value = (rx_buf[4] << 8) | rx_buf[5];
                if(Reg_Write(frame->start_reg, value)) {
                    // Эхо-ответ
                    tx_buf[2] = frame->start_reg >> 8;
                    tx_buf[3] = frame->start_reg & 0xFF;
                    tx_buf[4] = rx_buf[4];
                    tx_buf[5] = rx_buf[5];
                    tx_len = 6;
                } else {
                    tx_buf[1] |= 0x80;
                    tx_buf[2] = 0x03; // Ошибка данных
                    tx_len = 3;
                }
            }
            break;
        }
            
        default:
            tx_buf[1] |= 0x80;
            tx_buf[2] = 0x01; // Неподдерживаемая функция
            tx_len = 3;
            break;
    }
    
    // Добавляем CRC
    if(tx_len > 0 && frame->address != BROADCAST_ADDRESS) {
        uint16_t crc = Protocol_CRC16(tx_buf, tx_len);
        tx_buf[tx_len++] = crc & 0xFF;
        tx_buf[tx_len++] = crc >> 8;
    }
    
    return tx_len;
}

uint8_t Protocol_BuildEventFrame(uint8_t *tx_buf, uint8_t event_type, uint16_t data) {
    tx_buf[0] = 0xAA; // Стартовый байт события
    tx_buf[1] = Reg_GetAddress();
    tx_buf[2] = CMD_EVENT;
    tx_buf[3] = event_type;
    tx_buf[4] = data >> 8;
    tx_buf[5] = data & 0xFF;
    
    uint16_t crc = Protocol_CRC16(tx_buf, 6);
    tx_buf[6] = crc & 0xFF;
    tx_buf[7] = crc >> 8;
    
    return 8;
}